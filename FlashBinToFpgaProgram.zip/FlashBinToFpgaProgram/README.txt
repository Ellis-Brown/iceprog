Step 1) Update the drivers

1a) Follow this guide, specifically on the section libusb Driver Install:: https://learn.adafruit.com/adafruit-ft232h-breakout/windows-setup 
	Note: Zadig tool is already packaged with this installation

2) Run the "FlashToFPGA" Executable file and flash a bin file